package utilities;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import testbase.BaseClass;

public class ExtentReportManager implements ITestListener {
	
	public ExtentSparkReporter sparkReporter; //UI OF THE REPORT
	public ExtentReports extent;//populate common info in report
	public ExtentTest test;//
	
	String repName;
	
	
	public void onStart(ITestContext testContext) {
		
		/*SimpleDateFormat df= new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Date dt= new Date();
		String currentdatetimestamp=df.format(dt);*/
		
		String timeStamp=new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		repName="Test-Report-"+timeStamp+".html";
		sparkReporter=new ExtentSparkReporter(".\\reports\\" + repName);//specify the location to store the report
		
		
		sparkReporter.config().setDocumentTitle("Opencart Automation Report");
		sparkReporter.config().setReportName("Opencart Functional Testing");
		sparkReporter.config().setTheme(Theme.DARK);
		
		extent=new ExtentReports();
		extent.attachReporter(sparkReporter);
		
		extent.setSystemInfo("Application","Opencart");//setSystemInfo is the method with key values
		extent.setSystemInfo("Module","Admin");
		extent.setSystemInfo("Sub Module","Customers");
		extent.setSystemInfo("User Name",System.getProperty("user.name"));
		extent.setSystemInfo("Enviornment","QA");
		
		String os=testContext.getCurrentXmlTest().getParameter("os");
		extent.setSystemInfo("Operating System", os);
		
		String browser=testContext.getCurrentXmlTest().getParameter("browser");
		extent.setSystemInfo("Browser",browser);
		
		List<String> includedgroups=testContext.getCurrentXmlTest().getIncludedGroups();
		if(!includedgroups.isEmpty()) {
			extent.setSystemInfo("Groups", includedgroups.toString());
		}
		
	 }
	
	 public void onTestSuccess(ITestResult result) {
		 test=extent.createTest(result.getTestClass().getName()); //create new entry in the report
		 
		 test.assignCategory(result.getMethod().getGroups());//to display gropus in the report
		 
		 test.log(Status.PASS,result.getName()+"get successfully executed");//update status
		 
		  }
	 
	  public void onTestFailure(ITestResult result) {
		 test=extent.createTest(result.getTestClass().getName()); //create new entry in the report
		 test.assignCategory(result.getMethod().getGroups());//to display gropus in the report
		 
		 
		 test.log(Status.FAIL,result.getName()+"got failed");//update status
		 test.log(Status.INFO,result.getThrowable().getMessage());//update status
		 
		 //capturescreen method is under case class and we can't call that method directly so created object of baseclass
		 //capturescreen method will execute only when the test case fails
		 
		 try {
			String imgpath=new BaseClass().captureScreen(result.getName());//getting the name of method of the result
			test.addScreenCaptureFromPath(imgpath);//adding screenshot to report
			
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}//try catch blocks is needed as when the screen shot is not available to should not throw error
  }
	 	 
	 public void onTestSkipped(ITestResult result) {
		    test=extent.createTest(result.getTestClass().getName()); //create new entry in the report
		    test.assignCategory(result.getMethod().getGroups());
		    test.log(Status.SKIP,result.getName()+"got skipped");//update status
		    test.log(Status.INFO,result.getThrowable().getMessage()); //print error message
		  }
	 
	 
	 public void onFinish(ITestContext testContext) {
		 extent.flush();
		 
		 //open the report immediately after test execution
		 String pathOfExtentReport=System.getProperty("user.dir")+"\\reports\\"+repName; //path of the report generated
		 File extentReport=new File(pathOfExtentReport); //create file of the report
		
		 try {
		Desktop.getDesktop().browse(extentReport.toURI());
			 
		 }catch(IOException e) {
			 e.printStackTrace();
				
		 }
		 	   
		 }
}

	 
	
		


