package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountLogoutConfirm extends BasePage{
	
	//Constructor
	public AccountLogoutConfirm(WebDriver driver)
	{
		super(driver);
	}
	
	//locator
	
	@FindBy(xpath="//a[text()='Continue']") WebElement acclogoutbtn;
	
	//action method
	public void clickacclogout()
	{
		acclogoutbtn.click();
	}

}
