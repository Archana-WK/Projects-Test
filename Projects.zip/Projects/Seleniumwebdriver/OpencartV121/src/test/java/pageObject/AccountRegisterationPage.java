package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccountRegisterationPage extends BasePage {
	
	//constructor
	
	public AccountRegisterationPage(WebDriver driver)
	{
		super(driver);
	}
	
	//locators
	
	@FindBy(xpath="//input[@id='input-firstname']") WebElement txtFirstName;
	@FindBy(xpath="//input[@id='input-lastname']") WebElement txtLastName;
	@FindBy(xpath="	//input[@id='input-email']") WebElement txtEmail;
	@FindBy(xpath="//input[@id='input-telephone']") WebElement txtTelePhone;
	@FindBy(xpath="//input[@id='input-password']") WebElement txtPwd;
	@FindBy(xpath="//input[@id='input-confirm']") WebElement txtConfirmPwd;
	@FindBy(xpath="//label[normalize-space()='Yes']") WebElement chkbxYes;
	@FindBy(xpath="//input[@name='agree']") WebElement chkPolicy;
	@FindBy(xpath="//input[@value='Continue']") WebElement btnContinue;
	@FindBy(xpath="//h1[normalize-space()='Your Account Has Been Created!']") WebElement getConfirmation;
		
	
	
	public void setFirstName(String fname)
	{
		txtFirstName.sendKeys(fname);
	}
	public void setLastName(String lname)
	{
		txtLastName.sendKeys(lname);
	}
	public void setEmail(String email)
	{
		txtEmail.sendKeys(email);
	}
	public void setTelephone(String telePhone )
	{
		txtTelePhone.sendKeys(telePhone);
	}
	public void setPassword(String pwd)
	{
		txtPwd.sendKeys(pwd);
	}
	public void setConfirmPwd(String pwd)
	{
		txtConfirmPwd.sendKeys(pwd);
	}
	public void clickChkBox()
	{
		chkbxYes.click();
	}
	public void clickChkPolicy()
	{
		chkPolicy.click();
	}
	public void clcikContinue()
	{
		btnContinue.click();
	}
	
	public String getConfirmationMsg() {
		try{
			
			return(getConfirmation.getText()); //message is located and it is returned
			} catch(Exception e) {		//if the exception comes then return the exception msg
			return(e.getMessage());
			}
	
				
		}
		
	}

