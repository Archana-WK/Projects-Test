package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BasePage {
	
	WebDriver driver;
	
	public BasePage(WebDriver driver) //constructor name same as class name
	{
		this.driver=driver;
		PageFactory.initElements(driver,this); //using pagefactory model we are creating pageobject class
	}
	

}

