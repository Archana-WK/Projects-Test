package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage{
	
	//Constructor to invoke driver
	
	public LoginPage(WebDriver driver)
	{
		super(driver); //driver comes from base page so extend to basepage
	}
	
	//Locators
	@FindBy(xpath="//input[@id='input-email']") WebElement txtemailaddress;
	@FindBy(xpath="//input[@id='input-password']") WebElement txtpwd;
	@FindBy(xpath="//input[@value='Login']") WebElement loginbtn;
	
	//Action methods
	
	public void setemail(String email)
	{
		txtemailaddress.sendKeys(email);
	}
	
	public void setpassword(String password)
	{
		txtpwd.sendKeys(password);
	}
	public void clickloginbtn()
	{
		loginbtn.click();
	}
	

}
