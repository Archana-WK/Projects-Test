package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObject.HomePage;
import pageObject.LoginPage;
import pageObject.MyAccountPage;
import testbase.BaseClass;
import utilities.DataProviders;

public class TC003_LoginDDT extends BaseClass{
	
	/* Data is valid--Login success--Test passed--logout
	 * 				  Login failed--Test failed
	 * Data is Invalid--Login success--Test Failed--logout
	 * 				    Login failed--Test passed
	 */
	
	@Test(dataProvider="LoginData",dataProviderClass=DataProviders.class)
	
	public void verify_loginDDT(String email, String pwd, String exp) {
		
		logger.info("***********starting TC003_LoginPageDDT************");
		
		try
		{
		//Home Page
		HomePage hp=new HomePage(driver);
		hp.clickMyAccount();
		hp.clickLogin();
		
		//Login
		LoginPage lp=new LoginPage(driver);
		lp.setemail(email);
		lp.setpassword(pwd);
		lp.clickloginbtn();
		
		
		//MyAccount
		MyAccountPage macc=new MyAccountPage(driver);
		boolean myaccntexits=macc.isMyaccountpageexists();
		
		
		
		if(exp.equalsIgnoreCase("Valid"))
		{
			if (myaccntexits==true)
			{
				macc.clicklogout();
				
				Assert.assertTrue(true);
			}
			else
			{
				Assert.assertTrue(false);
			}
			
		}
		if(exp.equalsIgnoreCase("Invalid"))
		{
			if (myaccntexits==true)
			{
				macc.clicklogout();
				
				Assert.assertTrue(false);
			}
			else
			{
				Assert.assertTrue(true);
			}
		}
		
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		
		
		logger.info("***********Finished TC003_LoginPageDDT************");
	}
}
