package testCases;

import org.testng.Assert;

import org.testng.annotations.Test;

import pageObject.HomePage;
import pageObject.LoginPage;
import pageObject.MyAccountPage;
import testbase.BaseClass;

public class TC002_LoginPageTest extends BaseClass {
	
	@Test(groups= {"Sanity","Master"})
	
	public void Verify_Login()
	{
		logger.info("***********starting TC002_LoginPageTest Execution************");
		
		try //everything is kept is trycatch block to avoid exception
		{
			
		
		HomePage hp=new HomePage(driver);
		hp.clickMyAccount();
		hp.clickLogin();
				
		LoginPage lp=new LoginPage(driver);
		lp.setemail(p.getProperty("email"));
		lp.setpassword(p.getProperty("password"));
		lp.clickloginbtn();
		
		
		//MyAccount
		MyAccountPage macc=new MyAccountPage(driver);
		boolean myaccntexits=macc.isMyaccountpageexists();
		
		Assert.assertTrue(myaccntexits);    //Assert.assertEquals(myaccntexits, true, "Login failed");
		}
		catch(Exception e)
		{
			Assert.fail();
		}
		
		logger.info("***********Finished TC002_LoginPageTest Execution************");
	}

}
