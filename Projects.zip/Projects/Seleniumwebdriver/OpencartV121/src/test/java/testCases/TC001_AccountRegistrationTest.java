package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObject.AccountRegisterationPage;
import pageObject.HomePage;
import testbase.BaseClass;

public class TC001_AccountRegistrationTest extends BaseClass {
	
@Test(groups={"Regression","Master"})
 public void verify_accountregistration() {
	
	logger.info("Starting the execution of TC001_AccountRegistrationTest");
	
	
	try
	{		
		HomePage hp=new HomePage(driver);  //1. object of homepage
		hp.clickMyAccount();
		logger.info("clicked on My account");
		
		
		hp.clickRegister();
		logger.info("clicked on Register link");
		
		AccountRegisterationPage actr=new AccountRegisterationPage(driver);//2. object of account registration page
		
		logger.info("Adding account details");
		
		actr.setFirstName(randomeString());
		actr.setLastName(randomeString());
		actr.setEmail(randomeString()+"@gmail.com");
		actr.setTelephone(randomeNumeric());
		
		
		String password = randomeAlphaNumeric(); //here need to pass same randompassword in both fields so variable created
		actr.setPassword(password);
		actr.setConfirmPwd(password);
		actr.clickChkBox();
		actr.clickChkPolicy();
		actr.clcikContinue();
				
		String confirmsg=actr.getConfirmationMsg();
		
		if (confirmsg.equals("Your Account Has Been Created!"))
		{
			Assert.assertTrue(true);
		}
		else
		{
			logger.error("Test Failed");
			Assert.assertTrue(false);
		}
	
	}catch(Exception e)
	{
		Assert.fail();
	}
	
	logger.info("Finished test execution");
	logger.debug("Debug logs...");
	}
}

	
	

