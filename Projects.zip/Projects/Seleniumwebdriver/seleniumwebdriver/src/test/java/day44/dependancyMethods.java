package day44;

import org.testng.Assert;
import org.testng.annotations.Test;

public class dependancyMethods {
	
	@Test(priority=1)
	
	void openapp()
	{
		
		System.out.println("Openapp...");
		Assert.assertTrue(true);
	}
	
	@Test(priority=2, dependsOnMethods= {"openapp"})
	void login()
	{
		
		System.out.println("Login...");
		Assert.assertTrue(false);
	}
	
	@Test(priority=3, dependsOnMethods= {"login"})
	void search()
	{
		
		System.out.println("Search...");
		Assert.assertTrue(true);
	}
	@Test(priority=4, dependsOnMethods= {"search"})
	void advsearch()
	{
		
		System.out.println("Advasearch...");
		Assert.assertTrue(true);
	}
	@Test(priority=5, dependsOnMethods= {"openapp"})
	void Logout()
	{
		
		System.out.println("Logout...");
		Assert.assertTrue(true);
	}

}
