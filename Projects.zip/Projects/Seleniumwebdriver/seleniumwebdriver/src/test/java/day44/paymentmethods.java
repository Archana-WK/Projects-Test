package day44;

import org.testng.annotations.Test;

public class paymentmethods {
	
	@Test(priority=1, groups= {"sanity","regression","functional"})

	void paymentbycards()
	{
		System.out.println("payment by cards");
	}
	@Test(priority=2, groups= {"sanity","regression", "functional"})

	void paymentbycash()
	{
		System.out.println("payment by cash");
	}
}
