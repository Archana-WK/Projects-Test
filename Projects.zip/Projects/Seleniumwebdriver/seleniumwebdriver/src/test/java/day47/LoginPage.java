package day47;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//this is page object class

public class LoginPage {
	
	WebDriver driver;
	
	//constructor
	
	public LoginPage(WebDriver driver)//driver variable received from test case
	{
		this.driver=driver;//assign it to class variable used in methods below
	}
	
	
	//Locators
	
	By txt_username_loc=By.xpath("//input[@placeholder='Username']");	
	By txt_password_loc=By.xpath("//input[@placeholder='Password']");
	By btn_login_loc=By.xpath("//button[normalize-space()='Login']");
	
	
	
	//Action Methods
	public void setUsername(String username)
	{
		driver.findElement(txt_username_loc).sendKeys(username);
	}
	
	public void setPassword(String password)
	{
		driver.findElement(txt_password_loc).sendKeys(password);
	}
	
	public void clickLogin()
	{
		driver.findElement(btn_login_loc).click();
	}

}

