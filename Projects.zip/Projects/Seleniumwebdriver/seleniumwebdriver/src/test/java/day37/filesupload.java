package day37;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class filesupload {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
				
		driver.manage().window().maximize();
		//upload 1 file
		
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys("C:\\Users\\archana.futane\\OneDrive - Wolters Kluwer\\Local Drive D\\Test1.docx");
		
		if(driver.findElement(By.xpath("//li[normalize-space()='Test1.docx']")).getText().equals("Test1.docx"))
		{
			System.out.println("File uploaded successfully");
		}
		else {
			System.out.println("File upload failed");
		}
		
		//upload multiple files
		String file1="C:\\Users\\archana.futane\\OneDrive - Wolters Kluwer\\Local Drive D\\Test1.docx";
		String file2="C:\\Users\\archana.futane\\OneDrive - Wolters Kluwer\\Local Drive D\\Test2.docx";
		
		driver.findElement(By.xpath("//input[@id='filesToUpload']")).sendKeys(file1+"\n"+file2);
		System.out.println(driver.findElements(By.xpath("//ul[@id='fileList']//li")).size());
		
		//Validate the file names
	}
		
				

}
