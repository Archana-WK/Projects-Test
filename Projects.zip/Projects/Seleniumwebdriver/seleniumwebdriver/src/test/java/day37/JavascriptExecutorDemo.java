package day37;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavascriptExecutorDemo {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		//ChromeDriver driver1=new ChromeDriver();
		
		//driver is a WebDriver variable and it is object of Chromedriver
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement inputname=driver.findElement(By.xpath("//input[@id='name']"));
		
		//inputname.sendKeys("JOHN");
		
		//javascriptExecutor js=new javascriptExecutor(); //can't create object of inteface
		//type casting is required to refer the javascriptExecutor variable to webdriver variable
		
		JavascriptExecutor js=(JavascriptExecutor)driver; //Assigning driver variable to js variable
		
		//JavascriptExecutor js= driver1; // child class variable can hold parent class variable directly
		
		//setAttribute=option to sendKeys()
		
		js.executeScript("arguments[0].setAttribute('value', 'JOHN')",inputname);
		
		//select the radio button=--option to click()
		
		WebElement rdobtn=driver.findElement(By.xpath("//input[@id='male']"));
		js.executeScript("arguments[0].click()", rdobtn);
	}
	
	

}
