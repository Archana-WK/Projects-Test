package day38;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class screenshots {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.nopcommerce.com//");
		driver.manage().window().maximize();
		
		//1. Full page screen shots
		
		//TakesScreenShot ts= driver; 
		//when the ChromeDriver class is used 
		//as the child class varibale can be assigned to parent class
		
		//Type casting is done when the WedDriver interface is used
		TakesScreenshot ts= (TakesScreenshot)driver;//used when the webdriver interface variable is assigned to ts 
		File sourcefile=ts.getScreenshotAs(OutputType.FILE);//get the screenshot
		
		File targetfile=new File("C:\\Workspaces\\Eclipse\\Seleniumwebdriver\\seleniumwebdriver\\screenshots\\file1.png");
		
		sourcefile.renameTo(targetfile);
		
		

	}

}
