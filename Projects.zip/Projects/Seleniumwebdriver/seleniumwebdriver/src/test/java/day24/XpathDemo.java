package day24;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathDemo {

	public static void main(String[] args) {
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.opencart.com");
		driver.manage().window().maximize();
		
		 //Relative xpath with single attribute
		//driver.findElement(By.xpath("//input[@name='search']")).sendKeys("Tshirt");
		
		//Relative xpath with multiple attribute
		//driver.findElement(By.xpath("//input[@name='search'][@placeholder='Search']")).sendKeys("Tshirt"); //works same as and operator

		//Relative xpath with and or operator 
		//driver.findElement(By.xpath("//input[@name='search'and @placeholder='Sear']")).sendKeys("Tshirt");//it will fail
		//driver.findElement(By.xpath("//input[@name='search'or @placeholder='Sear']")).sendKeys("Tshirt"); //it will pass
		
		//Xpath with inner text- 
		//If the attribute are not available for the element than we use inner text along with text method
		//tag[text()=’INNER TEXT’]
		
				
		//driver.findElement(By.xpath("//a[text()='Desktops']")).click();
		/*boolean istextdisplyed=driver.findElement(By.xpath("//h3[text()='Featured']")).isDisplayed();
		System.out.println(istextdisplyed);
		
		String text=driver.findElement(By.xpath("//h3[text()='Featured']")).getText();
		System.out.println(text);
*/
		//Xpath with contains() method
		
		//driver.findElement(By.xpath("//input[contains(@placeholder, 'Se')]")).sendKeys("Tshirt");
		
		//Xpath with starts-with()method
		
		//driver.findElement(By.xpath("//input[starts-with(@placeholder,'Sea')]")).sendKeys("Tshirt");
		
		//chained xpath
		boolean status=driver.findElement(By.xpath("//div[@id='logo']/a/img")).isDisplayed();
		System.out.println(status);
	}

}
