package day36;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class keyboardactions {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://text-compare.com/");
		driver.manage().window().maximize();
		
		WebElement box=driver.findElement(By.xpath("//textarea[@id='inputText1']"));
		box.sendKeys("TEST");
		
		Actions act=new Actions(driver);
		
		//Select the text press ctr+A
		
		act.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
		
		//Copy the text ctr+C
		
		act.keyDown(Keys.CONTROL).sendKeys("C").keyUp(Keys.CONTROL);
		
		//Go to next text area --TAB
		act.keyDown(Keys.TAB).keyUp(Keys.TAB).perform();
		
		//Paste the text  cntr+V
		act.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).perform();
		
		
		
		
		
		
		
	}

}
