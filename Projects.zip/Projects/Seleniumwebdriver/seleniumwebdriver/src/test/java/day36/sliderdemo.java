package day36;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class sliderdemo {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.jqueryscript.net/demo/Price-Range-Slider-jQuery-UI/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Left bar coordinates
		
		WebElement left=driver.findElement(By.xpath("//span[1]"));
		System.out.println(left.getLocation()); //(59, 249)
		Actions act=new Actions(driver);
		
		act.dragAndDropBy(left, 100, 249).perform();
		
		//Right bar coordinates
		
		WebElement right=driver.findElement(By.xpath("//span[2]"));
		System.out.println(right.getLocation());//(412, 249)
		act.dragAndDropBy(right,-100,249).perform();
	}

}
