package day41;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.hpsf.Decimal;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FDCalculator {

	public static void main(String[] args) throws IOException, InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		driver.get("https://www.moneycontrol.com/fixed-income/calculator/state-bank-of-india-sbi/fixed-deposit-calculator-SBI-BSB001.html");
		driver.manage().window().maximize();
			
		
		String filepath=System.getProperty("user.dir")+"\\testdata\\caldata.xlsx";
		
		int rows=ExcelUtils.getRowCount(filepath,"Sheet1");
		
		for(int r=1;r<=rows;r++)
		{
			//read data from excel
			String principal=ExcelUtils.getCellData(filepath,"Sheet1",r,0);
			String rateofint=ExcelUtils.getCellData(filepath,"Sheet1",r,1);
			String prd1=ExcelUtils.getCellData(filepath,"Sheet1",r,2);
			String prd2=ExcelUtils.getCellData(filepath,"Sheet1",r,3);
			String Frq=ExcelUtils.getCellData(filepath,"Sheet1",r,4);
			String exp_matuvalue=ExcelUtils.getCellData(filepath,"Sheet1",r,5);
			
			//pass above data into application		
			
			driver.findElement(By.xpath("//input[@id='principal']")).sendKeys(principal);
			driver.findElement(By.xpath("//input[@id='interest']")).sendKeys(rateofint);
			driver.findElement(By.xpath("//input[@id='tenure']")).sendKeys(prd1);
			
			// Create object of the Select class
			Select select=new Select(driver.findElement(By.xpath("//select[@id='tenurePeriod']")));
			select.selectByVisibleText(prd2);
			
			Select sefre=new Select(driver.findElement(By.xpath("//select[@id='frequency']")));
			sefre.selectByVisibleText(Frq);
			
			//click on calculate
			driver.findElement(By.xpath("//div[@class='cal_div']//a[1]")).click();
			
			//Thread.sleep(3000);
			
			//validation
			String matuValue=driver.findElement(By.xpath("(//span[@id='resp_matval']//strong)")).getText();
			
		   ExcelUtils.setCellData(filepath,"Sheet1",r,6,matuValue);
			
		
			if(Double.parseDouble(exp_matuvalue)==Double.parseDouble(matuValue))
			{
				System.out.println("Test passed");
				ExcelUtils.setCellData(filepath,"Sheet1",r,7,"passed")	;
				ExcelUtils.fillGreenColor(filepath,"Sheet1",r,7);
			}
			else
			{
				System.out.println("Test Failed");
				ExcelUtils.setCellData(filepath,"Sheet1",r,7,"failed")	;
				ExcelUtils.fillRedColor(filepath,"Sheet1",r,7);
			}
			
			Thread.sleep(3000);
			
			//click on clear button
			driver.findElement(By.xpath("//img[@class='PL5']")).click();
		}
		driver.quit();
	}		

}


