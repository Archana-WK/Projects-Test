package day41;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Properties;
import java.util.Set;

public class ReadingPropertiesFile {

	public static void main(String[] args) throws IOException {
				
		//open the property file is reading mode
		
		FileInputStream ProFile = new FileInputStream(System.getProperty("user.dir")+"\\testdata\\config.properties");
		
		//Create object of properties class
		Properties propertiesObj=new Properties();
		
		//Load properties file
		propertiesObj.load(ProFile);
		
		//reading data from properties file
		String url=propertiesObj.getProperty("appurl");
		String username=propertiesObj.getProperty("email");
		String pwd=propertiesObj.getProperty("password");
		String orid=propertiesObj.getProperty("orderid");
		String cutid=propertiesObj.getProperty("customerid");
		
		System.out.println(url+" "+username+" "+pwd+" "+orid+" "+cutid);
		
		//reading all key values from property file
		
		Set<Object> keys = propertiesObj.keySet();		
		System.out.println(keys);
		
		//reading all values from property file
		Collection<Object> values= propertiesObj.values();
		System.out.println(values);
		
		
			

	}

}
