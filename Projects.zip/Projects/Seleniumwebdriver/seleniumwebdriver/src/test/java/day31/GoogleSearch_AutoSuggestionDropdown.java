package day31;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleSearch_AutoSuggestionDropdown {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("selenium");
		List<WebElement> seleniumcount=driver.findElements(By.xpath("//ul//div[@role='option']"));
		System.out.println("Total options" +seleniumcount.size());
		for(int i=0; i<seleniumcount.size();i++)
		{
			if (seleniumcount.get(i).getText().equals("selenium"))
			{
				seleniumcount.get(i).click();
				
				break;
			}
		}

	}

}
