package day31;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HiddenDropdown {

	public static void main(String[] args) throws InterruptedException {
			WebDriver driver=new ChromeDriver();
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");
			driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");
			driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
			Thread.sleep(5000);
			//Alert myalert=driver.switchTo().alert();
			//myalert.accept();
			

			driver.findElement(By.xpath(" //span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'][normalize-space()='PIM' ]")).click();
			
			//Click on dropdown button
			
			driver.findElement(By.xpath("//div[6]//div[1]//div[2]//div[1]//div[1]//div[2]//i[1]")).click();
			Thread.sleep(5000);
			
			//select the single option
			//driver.findElement(By.xpath("//span[normalize-space()='Chief Technical Officer']")).click();
			
			//get the option count
			List<WebElement> optionlist = driver.findElements(By.xpath("//div[@role='option'] [@class='oxd-select-option']"));
			
			System.out.println(optionlist.size());	
			
			for(WebElement optionsel:optionlist)
			{
				System.out.println(optionsel.getText());
				
				if(optionsel.getText().equals("Software Engineer"))
				{
					optionsel.click();
					
				}
				
			}
			
			
			

	}

}
