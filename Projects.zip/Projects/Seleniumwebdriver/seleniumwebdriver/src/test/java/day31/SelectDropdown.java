package day31;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("//select[@id='country']")).click();
		
		//For select class object to use we create the web element and pass that webelement in class object
		
		WebElement drpcountryEle=driver.findElement(By.xpath("//select[@id='country']"));//webelement created
		Select drpcountry=new Select(drpcountryEle); //pass webelement in select class object
		
		//drpcountry.selectByIndex(0);
		//drpcountry.selectByVisibleText("Canada");
		//drpcountry.deselectByValue("usa");
		
		//capture the number of options in a dropdown
		
		List<WebElement> options=drpcountry.getOptions(); //options will carry list of webelements
		
		//option is the list collections-list of webelements
		
		System.out.println("Number of options "+options.size() );
		
		//Printing the options
		
		/*(for(int i=0;i<options.size();i++)
		{
			System.out.println(options.get(i).getText());
			//get method will give the webelement and getText will return text in webelement
						
		}*/
		
		//using enhanced for loop print options
		
		for(WebElement opt:options)
		{
			System.out.println(opt.getText());
		}
	}

}
