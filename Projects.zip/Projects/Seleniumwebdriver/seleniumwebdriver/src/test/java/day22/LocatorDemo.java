package day22;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.List;
import org.openqa.selenium.WebElement;


public class LocatorDemo {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		//driver.get("https://demo.opencart.com");
		//driver.manage().window().maximize();
		
		//name locator
		//driver.findElement(By.name("search")).sendKeys("Mac");
		
		//id
		
		//boolean isdisplayed=driver.findElement(By.id("logo")).isDisplayed();
		//System.out.println(isdisplayed);
		
		//linktext and partial link text
		
		//driver.findElement(By.linkText("Tablets")).click();
		//driver.findElement(By.partialLinkText("Table")).click();
		
		//class name- here we are capturing multiple web elements 

		//ul=user list - user list will have list items
		//li=list item
		
		//List<WebElement> hederlinks=driver.findElements(By.className("list-inline-item"));
		
		//list<WebElement> is the return type of findElement
		//list is java collection
		//list will hold the duplicate so prefered to use List instead of Set
		
		//System.out.println("total no of hederlinks " +hederlinks.size());
		
		//tag name-find no of links available on page
		
		//<a is the common tag for all links
		
		//List<WebElement> linksnumber = driver.findElements(By.tagName("a"));
		//System.out.println(linksnumber.size());
		
		//tag name-to find total number of images
		//List<WebElement> images= driver.findElements(By.tagName("img"));
		//System.out.println(images.size());
		
		driver.get("https://www.demoblaze.com/index.html");
		driver.manage().window().maximize();
		
		Thread.sleep(5000); //5 sec delay added to load the image and then click on the link
		
		//1. click on any product link using linkText/partialLinkText
		
		//driver.findElement(By.linkText("Samsung galaxy s6")).click();
		//driver.findElement(By.partialLinkText("s6")).click();
		
		//2. to find total number of images on web
		//List<WebElement> totalimages =driver.findElements(By.tagName("img"));
		
		//System.out.println(totalimages.size());
		
		//3. to find total no of links
		List<WebElement> linkstotal=driver.findElements(By.tagName("a"));
		System.out.println(linkstotal.size());
		
	}

}
