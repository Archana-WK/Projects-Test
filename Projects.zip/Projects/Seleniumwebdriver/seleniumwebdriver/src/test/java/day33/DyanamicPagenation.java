package day33;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DyanamicPagenation {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demo.opencart.com/admin/index.php");
		driver.manage().window().maximize();
		
		//clear the username and then send the demo as username
		//pass password
		
		//click on login button
		//close the information window--if the window is displayed then close the window
		
		//click on customers main menu
		//click on customers sub menu
		//get the text meassage
		//get the total page numbers
		//repeating pages and click
		//reading data from each pages
		

	}

}
