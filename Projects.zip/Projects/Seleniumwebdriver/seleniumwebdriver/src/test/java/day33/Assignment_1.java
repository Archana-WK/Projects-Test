package day33;

public class Assignment_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
