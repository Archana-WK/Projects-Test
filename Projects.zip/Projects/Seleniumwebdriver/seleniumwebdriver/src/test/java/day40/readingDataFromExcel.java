package day40;

import java.io.FileInputStream;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class readingDataFromExcel {

	public static void main(String[] args) throws IOException {
		
		//FileInputStream file= new FileInputStream("C:\\Workspaces\\Eclipse\\Seleniumwebdriver\\seleniumwebdriver\\testdata\\Test1.xlsx")
		//create testdata folder and add excel file in folder
		//get the file
		
		FileInputStream file= new FileInputStream(System.getProperty("user.dir")+"\\testdata\\Test1.xlsx");
		
		//get the workbook from file
		XSSFWorkbook workbook=new XSSFWorkbook(file);
				
		//get the specific sheet from workbook
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		
		int totalrows=sheet.getLastRowNum();
		int totalcells=sheet.getRow(0).getLastCellNum();
		
		System.out.println("total number of rows"+ totalrows);
		System.out.println("total number of columns"+ totalcells);
		
		for(int r=0;r<=totalrows;r++)
		{
			//get the row 
			XSSFRow currentrow=sheet.getRow(r); //XSSFRow return type getRow()
			
			for(int c=0;c<totalcells;c++)
			{
				
				XSSFCell currentcell=currentrow.getCell(c);//XSSFCell return type getCell()
				System.out.print(currentcell.toString()+"\t");
				
			}
			
			System.out.println(); //this will go to new line
			
		}
		
        workbook.close(); //mandatory step when the workbook variable is created add this code
        file.close();
	}

}
