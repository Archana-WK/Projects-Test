package day40;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class writingDataInExcel {

	public static void main(String[] args) throws IOException  {
		
		FileOutputStream file=new FileOutputStream(System.getProperty("user.dir")+"\\testdata\\Test2.xlsx");
		
		//create the workbook		
		XSSFWorkbook workbook= new XSSFWorkbook();
		
		//create sheet		
		 XSSFSheet sheet1=workbook.createSheet("Sheet1");
		 
		 //adding data in row 0 hardcoded
		 
			 XSSFRow row=sheet1.createRow(0);
			 row.createCell(0).setCellValue("Automation");
			 row.createCell(1).setCellValue("Automation1");
			 row.createCell(2).setCellValue("Automation2");
			 
			//adding data in row 1 hardcoded
			 XSSFRow row1=sheet1.createRow(1);
			 row1.createCell(0).setCellValue("Java");
			 row1.createCell(1).setCellValue("Java1");
			 row1.createCell(2).setCellValue("Java2");
			 
			 System.out.println("File is created");
		
		workbook.write(file);//attach workbook to file
		workbook.close();
		file.close();
		

	}
	
	
	
}



