package day40;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class writingDynamicDataInExcel {

	public static void main(String[] args) throws IOException {
		FileOutputStream file=new FileOutputStream(System.getProperty("user.dir")+"\\testdata\\Test3.xlsx");
		
		//create the workbook
		XSSFWorkbook workbook=new XSSFWorkbook();
		
		//create sheet
		
		XSSFSheet sheet=workbook.createSheet("Sheet");
		
		//input value from user
		Scanner sc=new Scanner(System.in);
	    
		System.out.println("Entre Number of rows");
		int	totalrows=sc.nextInt();
		
		System.out.println("Entre Number of columns");
		int	totalcolumns=sc.nextInt();
		
		for(int r=0;r<=totalrows;r++)
		{
			XSSFRow row=sheet.createRow(r);
								
			for(int c=0;c<totalcolumns;c++)
			{
				XSSFCell col=row.createCell(c);
				
			System.out.println("Entre cell value");
			col.setCellValue(sc.next());  //next() used as any string data can be added
			}
			
		}
		System.out.println("file is created");
				
		workbook.write(file);
		workbook.close();
		file.close();
		
		
	}
	

}
