package day35;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class doubleclickactions {

	public static void main(String[] args) {
    WebDriver driver=new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Locate three elements
		
		WebElement box1=driver.findElement(By.xpath("//input[@id='field1']"));
		box1.clear();
		box1.sendKeys("WELCOME");
		
		WebElement box2=driver.findElement(By.xpath("//input[@id='field2']"));
		WebElement button=driver.findElement(By.xpath("//button[normalize-space()='Copy Text']"));
		
		Actions act=new Actions(driver);
		act.doubleClick(button).perform();
		
		//here getAttribute is used instead of getText as box2 element does not have inner text
		
		System.out.println(box2.getAttribute("value"));
		

	}

}
