package day35;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class mouseoveractiondemo {

	public static void main(String[] args) {
		

			
				WebDriver driver= new ChromeDriver();
				driver.get("https://demo.opencart.com");
				driver.manage().window().maximize();

				//Mouse hover actions
				//first find the element which are mouse hovered
				
				WebElement desktop=driver.findElement(By.xpath(" //a[normalize-space()='Desktops']"));
				WebElement mac=driver.findElement(By.xpath("//a[normalize-space()='Mac (1)']"));
				
				//create actions class object
				Actions act=new Actions(driver); //Actions class contains the constructor which expects the driver as the parameter
				//act.moveToElement(desktop).build().perform();
				act.moveToElement(desktop).perform();
				
				act.moveToElement(mac).click().perform();
				
				
			
			}
		}
			


