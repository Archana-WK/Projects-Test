package day35;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class rightclickactions {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new ChromeDriver();
		driver.get("http://swisnl.github.io/jQuery-contextMenu/demo.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//find the element
		WebElement button=driver.findElement(By.xpath("//span[@class='context-menu-one btn btn-neutral']"));
		WebElement copybutton=driver.findElement(By.xpath("//span[normalize-space()='Copy']"));
		
		
		Actions act=new Actions(driver);
		act.contextClick(button).perform();		
		
		copybutton.click();
		
		//ALERT window appears
		//driver.switchTo().alert().accept();
		String text=driver.switchTo().alert().getText();	
		System.out.println(text);
		
		
		
		
		
		
	
		
		
		
		
		
				


	}

}
