package day35;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class draganddropactions {

	public static void main(String[] args) {
		 WebDriver driver=new ChromeDriver();
			
			driver.get("https://testautomationpractice.blogspot.com/");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			
			//drag and drop actions
			WebElement box1=driver.findElement(By.xpath("//div[@id='draggable']"));
			WebElement box2=driver.findElement(By.xpath("//div[@id='droppable']"));
			
			Actions act=new Actions(driver);
			
			//act.dragAndDrop(box1, box2).perform(); //build+complete
			
			//Actions vs Action (use of build action)
			
			
			Action act2=act.dragAndDrop(box1, box2).build();//Create//store action in a variable using Action
			
			act2.perform(); //create +complete
			
			
			
			
			
		

	}

}
