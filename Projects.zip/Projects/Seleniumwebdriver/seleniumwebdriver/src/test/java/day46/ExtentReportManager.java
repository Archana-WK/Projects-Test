package day46;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager implements ITestListener
{
	public ExtentSparkReporter sparkReporter; //UI OF THE REPORT
	public ExtentReports extent;//populate common info in report
	public ExtentTest test;//
	
	
	public void onStart(ITestContext context) {
		sparkReporter=new ExtentSparkReporter(System.getProperty("user.dir")+"/reports/myreport.html");
		sparkReporter.config().setDocumentTitle("Automation Report");
		sparkReporter.config().setReportName("Functional Testing");
		sparkReporter.config().setTheme(Theme.DARK);
		
		extent=new ExtentReports();
		extent.attachReporter(sparkReporter);
		
		extent.setSystemInfo("Computer Name","localhost");//setSystemInfo is the method with key values
		extent.setSystemInfo("Environment","QA");
		extent.setSystemInfo("Tester Name","Archana");
		extent.setSystemInfo("os","windows10");
		extent.setSystemInfo("Browser Name","Chrome");
		
		  }
	
		
	 public void onTestSuccess(ITestResult result) {
		 test=extent.createTest(result.getName()); //create new entry in the report
		 test.log(Status.PASS,"Test case passed is"+result.getName());//update status
		 
		  }
	 
	 
	 public void onTestFailure(ITestResult result) {
		 test=extent.createTest(result.getName()); //create new entry in the report
		 test.log(Status.FAIL,"Test case Failed is"+result.getName());//update status
		 test.log(Status.FAIL,"Test case Failed cause is"+result.getThrowable());//update status
		    
		    
		  }
	 
	 
	 public void onTestSkipped(ITestResult result) {
		    test=extent.createTest(result.getName()); //create new entry in the report
		    test.log(Status.SKIP,"Test case skipped is"+result.getName());//update status
		  }
	 
	 
	 public void onFinish(ITestContext context) {
		 extent.flush();
		   
		  }
	 
	
		

}
