package day29;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleCheckboxes {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//Select a checkbox
		// driver.findElement(By.xpath("//input[@id='sunday']")).click();
		 
		 //select all checkboxes
		List<WebElement> checktheboxes= driver.findElements(By.xpath("//input[@class='form-check-input'and @type='checkbox']"));
		 
		/*for(int i=0;i<checktheboxes.size();i++)
		{
			checktheboxes.get(i).click();
		}*/
		
		//select last three checkboxes
		
		/*for(int i=4;i<checktheboxes.size();i++)
		{
			checktheboxes.get(i).click();
		}*/
		
		//select first three checkboxes
		
		
		
		//unselect the selected first three checkbox
		
		for(int i=0;i<checktheboxes.size()-4;i++)
		{
			if(checktheboxes.get(i).isSelected())
			{
				checktheboxes.get(i).click();
			}
			
		}

	}

}
