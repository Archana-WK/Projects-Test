package day29;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleAlerts {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		
		//1. normal alert with ok button
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Alert']")).click();
		Thread.sleep(5000);
		
		//driver.switchTo().alert().accept(); //jump to alert window 
		
		Alert myalert=driver.switchTo().alert(); //jump to alert window and create the alert referanec variable
		
		System.out.println(myalert.getText());
		
		myalert.accept();   //to click on OK button we accept it
		
		//2. Confirmation -ok/cancle button
		
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Confirm']")).click();
		Alert myalert1=driver.switchTo().alert();	
		
		System.out.println(myalert1.getText());
		//myalert1.accept(); //close alert using ok button 
		myalert1.dismiss();	////close alert using cancle button 
		System.out.println(driver.findElement(By.xpath("//p[@id='result']")).getText());
		
		//3. Prompt alert-Input box-use send keys to pass text
		
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Prompt']")).click();
		
		Alert myalert3= driver.switchTo().alert();
		myalert3.sendKeys("Welcome");
		myalert.accept();
		System.out.println(driver.findElement(By.xpath("//p[@id='result']")).getText());
		
		
		
		
		
		
		
		}

}
