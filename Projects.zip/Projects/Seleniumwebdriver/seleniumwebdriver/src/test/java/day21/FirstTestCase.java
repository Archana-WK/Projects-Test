package day21;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.WebDriver;

//test cases
//1)launch browser
//2)open the url https://demo.opencart.com/
//3)Validate title should be 'your store"
//4)close browser


public class FirstTestCase {

	public static void main(String[] args) {
		 //1. Launch chrome browser
		
		//create chromedriver class object 
		//ChromeDriver is the constructor which is invoked and that will invoke the browser
		
		//either of below can be used to invoke chrome browser
		
		ChromeDriver driver=new ChromeDriver();
		//WebDriver driver=new ChromeDriver();//upcasting chromedriver is child class of webdriver parent class
		//WebDriver driver=new EdgeDriver();
		
		//2. open the url https://demo.opencart.com/
		
		driver.get("https://demo.opencart.com");
		
		//3)Validate title should be 'your store"
		
		//get the title after invoking the chrome browser
		
		String act_title=driver.getTitle();
		System.out.println(act_title);
		
		if(act_title.equals ("Your Store"))
		{
			System.out.println("Correct page");
			
		}
		else 
		{
			System.out.println("Incorrect page");
		}
		 
		//4) Close browser
		driver.close();
		//driver.quit();
		 
	}

}
