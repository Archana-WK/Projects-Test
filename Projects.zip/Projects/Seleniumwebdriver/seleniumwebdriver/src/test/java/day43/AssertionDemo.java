package day43;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AssertionDemo {
	
	
	@Test
	
	void test1()
	{
		String Ext_Title="Opencart";
		String Act_Title="Openshop";
		
		/*if(Ext_Title.contains(Act_Title))
		{
			System.out.println("Test passed");
		}
		else
		{
			System.out.println("Test failed");
		}*/
		
		//here the if elsencondition will not make the class failed 
		//Assert class will make the class failed if the condition did not match
		
		Assert.assertEquals(Ext_Title,Act_Title);
	}

	
}
