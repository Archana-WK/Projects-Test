package day43;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class HardVsSoftAssertion {
	
	//@Test
	void HardAssert()
	{
		System.out.println("Testing...");
		System.out.println("Testing1...");
		
		Assert.assertEquals("abc", "xyz");//Hard assert-Static method-can access direct from Assert class
		
		//if hard assertion method fails then rest of statements will not be executed
		
		System.out.println("Testibg2....");
		
		
	}
	
	@Test
	void SoftAssert()
	{
		System.out.println("Testing...");
		System.out.println("Testing1...");
		
		//soft assert method can be accessible only through object of soft assert method
		//soft assert method are not static methods, they need to be accessed to SoftAssert class object
		//if soft assertion method fails still the rest of statements will be executed
		
		SoftAssert sa=new SoftAssert();
		
		sa.assertEquals("abc", "xyz");
		
		System.out.println("Testibg2....");
		
		sa.assertAll();//Mandatory
		
		
	}
	
	

}
