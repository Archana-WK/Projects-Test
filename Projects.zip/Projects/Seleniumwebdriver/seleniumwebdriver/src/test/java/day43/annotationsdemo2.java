package day43;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/*
 * TC2
1.	Login--@BeforeClass --it will execute before starting of class execution-before execution of all tests
2.	Search@Test
3.	Advanced Search@Test
4.	Logout-- --@AfterClass it will execute after completion of class execution

 */

public class annotationsdemo2 {
	
	@BeforeClass
	
	void login()
	{
		System.out.println("Login....");
	}
	
	@AfterClass
	
	void logout()
	{
		System.out.println("Logout....");
	}
	
	@Test(priority=1)
	
	void search()
	{
	System.out.println("This is search");
	}
	
	@Test(priority=2)
	
	void advancedsearch()
	{
	System.out.println("This is advanced search");
	}


}
