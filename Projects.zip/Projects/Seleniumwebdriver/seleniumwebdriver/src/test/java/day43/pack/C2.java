package day43.pack;

import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class C2 {
	
	@Test
	
	void abc() {
		System.out.println("This is xyz from C2");
	}
	
	@AfterTest
	
	void at() {
		
		System.out.println("This is after test method");

	}
	

}
