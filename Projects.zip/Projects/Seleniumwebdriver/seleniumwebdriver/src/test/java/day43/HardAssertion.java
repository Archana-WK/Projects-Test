package day43;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssertion {
	
	@Test
		
	void test()
	{
		//Assert.assertEquals(123,"abc");//failed
		//Assert.assertEquals("abc", "abc");//passed
		//Assert.assertEquals("123", 123);//failed
		//Assert.assertTrue(1==2);//failed
		Assert.assertFalse(1==2);//Passed
			
		
	}

}
