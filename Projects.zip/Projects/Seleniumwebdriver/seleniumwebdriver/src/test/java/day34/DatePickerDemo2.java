package day34;

import java.time.Duration;
import java.time.Month;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DatePickerDemo2 {
	
	//user defined object will convert the string to month class
	//we can not compare the two month names as it is in string format so need to create month object
	
	static Month convertstringtomonth(String month){
		HashMap<String, Month> monthmap=new HashMap<String, Month>();
		
		monthmap.put("January", Month.JANUARY); //Month is a object--key object format
		monthmap.put("February", Month.FEBRUARY);
		monthmap.put("March", Month.MARCH);
		monthmap.put("April", Month.APRIL);
		monthmap.put("May", Month.MAY);
		monthmap.put("June", Month.JUNE);
		monthmap.put("July", Month.JULY);
		monthmap.put("August", Month.AUGUST);
		monthmap.put("September", Month.SEPTEMBER);
		monthmap.put("October", Month.OCTOBER);
		monthmap.put("November", Month.NOVEMBER);
		monthmap.put("December", Month.DECEMBER);
		
		Month vmonth=monthmap.get(month);
		
		if(vmonth==null) {
			System.out.println("This is not a month");
		}
		return vmonth;
	}
		
	static void selectDate(WebDriver driver, String requiredyear, String requiredmonth, String requireddate)
	{
	//select year
	WebElement yeardropdown= driver.findElement(By.xpath("//select[@class='ui-datepicker-year']"));
	Select chooseYear=new Select(yeardropdown);
	chooseYear.selectByValue(requiredyear);
	
	while(true)
	{
	//select month
	String currentMonth=driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
	
	
	
	//convert months to month object for comparision
		
	Month displayedMonth=convertstringtomonth(currentMonth);
	Month expectedMonth=convertstringtomonth(requiredmonth);
	
	//Campare months
	
	int result=expectedMonth.compareTo(displayedMonth);//expectedmonth-displayedmonth=result
	
	//result=0
	//result>0  future month
	//result<0	past month
	
	if(result>0)
	{
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();  //future month
	}
	else if(result<0)
	{
		driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();//past month
	}
	else
	{
		break;
	}
}
	
	//select date
	List<WebElement>alldates=driver.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tbody//tr//a"));
	for(WebElement dt:alldates)
	{
		if (dt.getText().equals(requireddate))
		{
			dt.click();
			break;
		}
		
	}	

		
	}
		
			
	
	

	public static void main(String[] args) throws InterruptedException{
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//input DOB fields
		String requireddate="20";
		String requiredmonth="May";
		String requiredyear="2025";
		
		driver.switchTo().frame("frame-one796456169");
		
		driver.findElement(By.xpath("//span[@class='icon_calendar']")).click();
		Thread.sleep(5000);
	
		selectDate(driver,requiredyear,requiredmonth,requireddate);
		
		}
}

