package day26;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConditionalMethods {

	public static void main(String[] args) {
    WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.nopcommerce.com/en/register");
		driver.manage().window().maximize();
		
		//isDisplayed()
		//WebElement logo = driver.findElement(By.xpath("//img[@title='nopCommerce']"));
		//System.out.println(logo.isDisplayed());
		
		// boolean status=driver.findElement(By.xpath("//img[@title='nopCommerce']")).isDisplayed();
		 //System.out.println(status);
		 
		 //isEnabled
		//WebElement enable_fn= driver.findElement(By.xpath("//input[@id='FirstName']"));
		//System.out.println("enable_fn");
		 
		 //isSelected
		

	}

}
