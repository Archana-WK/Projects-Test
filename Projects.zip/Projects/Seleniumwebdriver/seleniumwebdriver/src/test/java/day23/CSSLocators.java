package day23;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CSSLocators {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();  //to import the packages ctr+shift+o
		//driver.get("https://demo.nopcommerce.com/");
		//driver.manage().window().maximize();
		
		
	//tag id-->  tag#id
		//driver.findElement(By.cssSelector("input#small-searchterms")).sendKeys("T-Shirt");
		// tag is not mandatory
		//driver.findElement(By.cssSelector("#small-searchterms")).sendKeys("T-Shirt");
		
		
	//tag classname   tag.classname
		
		//driver.findElement(By.cssSelector("input.search-box-text")).sendKeys("T-shirt");
		//driver.findElement(By.cssSelector(".search-box-text")).sendKeys("T-shirt");
		
	//tag attribute     tag[attribute="value"]
		
		//driver.findElement(By.cssSelector("input[placeholder='Search store']"));
		//driver.findElement(By.cssSelector("[placeholder='Search store']"));
		
	//tag class attribute   tag.classname[attribute="value"]
		//driver.findElement(By.cssSelector("input.search-box-text[placeholder='Search store']")).sendKeys("Tshirt");
	
		driver.get("https://demo.opencart.com/");
		driver.manage().window().maximize();
		
		//search box
	//tag[attribute="value"]
		//driver.findElement(By.cssSelector("input[placeholder='Search']")).sendKeys("Tshirt");
		
	//tag.classname[attribute="value"]
		
		driver.findElement(By.cssSelector("input.form-control[placeholder='Search'])")).sendKeys("Tshirt");
		
		
	}
	
}




