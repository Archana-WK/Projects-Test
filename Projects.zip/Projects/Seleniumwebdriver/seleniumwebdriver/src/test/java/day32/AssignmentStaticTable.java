package day32;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AssignmentStaticTable {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://blazedemo.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//select[@name='fromPort']")).click();
		WebElement option=driver.findElement(By.xpath("//select[@name='fromPort']"));
		Select optionset=new Select(option);
		optionset.selectByValue("Paris");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//select[@name='toPort']")).click();
		WebElement option1=driver.findElement(By.xpath("//select[@name='toPort']"));
		Select optionset1=new Select(option1);
		optionset1.selectByValue("Rome");
		
		driver.findElement(By.xpath("//input[@value='Find Flights']")).click();
		
		//find the number of rows
		List<WebElement> rows=driver.findElements(By.xpath("//table[@class='table']//tr"));
		int r=rows.size();
		System.out.println(r);
		
		//find number of columns
		List<WebElement> col=driver.findElements(By.xpath("//table[@class='table']//th"));
		int cl=col.size();
		System.out.println(cl);
		
		String st=driver.findElement(By.xpath("//table[@class='table']//th[6]//tr[1]")).getText();
		System.out.println(st);
		
		
		
		/*for(int i=1;i<r;i++)
			
		{
						
			List<WebElement> pricelist=driver.findElements(By.xpath("//table[@class='table']//th['+cl+']//tr['+i+']"));
			WebElement price=pricelist.get(i);
			String pricefor = price.getText();
			System.out.println(pricefor);
					
			
		}*/
		
		
	}
	

}
