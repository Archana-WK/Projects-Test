package day32;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class staticTable {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//find total number of rows in a table
		List<WebElement> rowlist=driver.findElements(By.xpath("//table[@name='BookTable']//tr"));
		int rowcnt=rowlist.size();
		System.out.println("Number of rows "+rowcnt);
		
		//find total number of columns in a table
		List<WebElement> collist=driver.findElements(By.xpath("//table[@name='BookTable']//th"));
		int colcnt=collist.size();
		System.out.println("Number of columns "+colcnt);
		
		
		//read data from specific row and column(5th row and 1 column)
		String data1=driver.findElement(By.xpath("//table[@name='BookTable']//tr[5]//td[1]")).getText();
		System.out.println(data1);
		
		//read data from all row and column
		
		for(int r=2;r<rowcnt;r++)
		{
			for(int cl=1;cl<colcnt;cl++)
			{
				String data2=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td["+cl+"]")).getText();
				System.out.print(data2+"\t");
			}
				System.out.println();
		}
		
		
		//print bookname whose author is Mukesh
		for(int r=2;r<rowcnt;r++)
		{
			
				String data2=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[2]")).getText();
				if(driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[2]")).getText().equals("Mukesh"))
				{
					String auther=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[1]")).getText();
					System.out.println(auther);
				}
				
		}
		
		
		//find total price of all book
		int sum=0;
		for(int r=2;r<rowcnt;r++)
		{
			
				String data3=driver.findElement(By.xpath("//table[@name='BookTable']//tr["+r+"]//td[4]")).getText();
				System.out.println(data3);
				int num=Integer.parseInt(data3);
				sum=num+sum;
		}
		System.out.println(sum);
		
			}

}
