package day27;

import java.time.Duration;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FluentWaitDemo {

	public static void main(String[] args) throws InterruptedException {
		
			WebDriver driver=new ChromeDriver();
			
		//FluentWait Declaration 
		//FluentWait is the class which interface Wait interface
		//Wait is the interface
		//mywait is the object of fluentwait
			
			 Wait<WebDriver> mywait = new FluentWait<WebDriver>(driver)
					 
				            .withTimeout(Duration.ofSeconds(10))// // Waiting 30 seconds for an element to be present on the page, checking
				            .pollingEvery(Duration.ofMillis(300)) //for its presence once every 5 seconds.
				            .ignoring(ElementNotInteractableException.class); //ignore specific types of exceptions
				            
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");            

			//Usage part
			
			WebElement txtusername = mywait.until(new Function<WebDriver, WebElement>()  //condition
			   {
			     public WebElement apply(WebDriver driver)
			     {
			      return driver.findElement(By.xpath("//input[@placeholder='Username']"));
			     }
			   });
			txtusername.sendKeys("Admin");
		
		
		/*WebElement textusername= mywait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Username']")));
		//this will return webelement
		//above statement will locate the web element due to condition and when it becomes true it will be available at webelement ref variable.
		
		textusername.sendKeys("Admin");
				
			
		WebElement textpassword= mywait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Password']")));
		textpassword.sendKeys("admin123");
			
		WebElement loginbutton = mywait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[normalize-space()='Login']")));
		loginbutton.click();
		
			//driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Admin");*/
			
			

	}

}
