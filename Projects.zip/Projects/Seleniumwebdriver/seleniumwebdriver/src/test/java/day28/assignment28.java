package day28;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class assignment28 {

	public static void main(String[] args) throws InterruptedException {
				
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.xpath("//input[@id='Wikipedia1_wikipedia-search-input']")).sendKeys("Selenium");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		//driver.findElement((By.xpath("//a[normalize-space()='Selenium']")));
		
		//size of all links under search button
		
		//List<WebElement> linklist=driver.findElements(By.id("wikipedia-search-result-link"));
		
		//List<WebElement> linklist=driver.findElements(By.xpath("//div[@id='wikipedia-search-result-link']"));
											
		//int idlist=linklist.size();
		//System.out.println(idlist);
		
		//click all the links under search button
		
		Thread.sleep(5000);
		
		List<WebElement> linklist=driver.findElements(By.partialLinkText("Selenium"));
		 
		for(int i=0;i<linklist.size();i++)
		{
			linklist.get(i).click();		
		
		}
		
		//get window ids for each browser window
		
		Set<String> winid=driver.getWindowHandles();
		System.out.println(winid); //window id are in set
		
		
		List<String> windowidis= new ArrayList(winid);
		
		for(int m=0;m<windowidis.size();m++)
		{
			String idis=windowidis.get(m);
			System.out.println("Window ids are " +idis);
		}
		
		//close specific browser window
	
		for(String idwin:windowidis)
		{
			String title=driver.switchTo().window(idwin).getTitle();
			System.out.println("Title is "+title);
			
			if(title.equals("Selenium dioxide - Wikipedia" ))
			{
				driver.close();
			}
		}
		
		
		
		
		
	
		/*boolean dis=driver.findElement(By.xpath("//div[@id='Wikipedia1_wikipedia-search-results']//div[1]")).isDisplayed();
		
		System.out.println(dis);*/
		
		/*for(i=0;i<=count;i++)
		{
		boolean dis=driver.findElement(By.xpath("//div[@id='Wikipedia1_wikipedia-search-results']//div[i]")).isDisplayed();
				if(dis==true)
				{
					count++;
					
					
				}
		}
		System.out.println(count);
		
		
		/*if()
		String title= driver.getTitle();
		if(title.contains("Selenium")
		{
			count++;
			
		}*/
		
		

	}

}
