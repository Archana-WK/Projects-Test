package day28;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class navigationalcommanddemo {

	public static void main(String[] args) throws MalformedURLException {
		

		WebDriver driver=new ChromeDriver();
		//driver.get("https://www.nopcommerce.com/en/register");  //accepts the URL as string
		
		//driver.navigate().to("https://demo.nopcommerce.com/"); //accepts the URL as string
		
		//URL is a class and myurl is the object of URL class and in constructor pass the url as string
		
		//URL myurl=new URL("https://www.nopcommerce.com/en/register");//accepts the URL as URL object
		//driver.navigate().to(myurl);
		
		
		driver.navigate().to("https://demo.nopcommerce.com/"); //accepts the URL as string
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.navigate().back();
		System.out.println(driver.getCurrentUrl());
		
		driver.navigate().forward();
		System.out.println(driver.getCurrentUrl());
		
	}

}
