package day19;

//upcasting-converting data type from smaller to larger
//byte-short-int-long-float-double--> order of data from smaller to larger data type
//ex-int to long or float to double


//Downcasting- converting from larger data type to smaller data type
//ex. double to float
//ex. long to int

public class TypeCastingDemo {

	public static void main(String[] args) {
		
		//upcasting
		int intvalue=100;
		long longvalue=intvalue;
		
		//downcasting
		double dvalue=10.3456789045678F;
		float fvalue=(float) dvalue; //casting applied
		System.out.println(fvalue);
		
		long lvalue=1234567891;
		int ivalue=(int) lvalue;   //casting applied
		System.out.println(ivalue);
		 
		double dvalue1=10.5;
		int i=(int) dvalue1;
		System.out.println(i);
		

	}

}
