package day19;

// A B =(C) D
//Rule 1= relation between C and D
//Rule 2= C' must be same or child of 'A'
//Rule 3= underlying object of D should be same as C or child of C


public class TypeCastingObject3 {

	public static void main(String[] args) {
		
		/*EX1-
		Object o=new String("welcome");
		StringBuffer sb=(StringBuffer) o;
		
	//rule 1='Object' is the parent of all classes so StringBuffer is also child of Object class
	//rule 2= C is same as A
	//rule 3= underlying object of o is String and String and StrinBuffer(C) are not having relation between them*/
		
	
		//EX2
		//String s=new String("welcome");
		//StringBuffer sb=(StringBuffer) s;//Rule 1-failed- no relation between string and stringbuffer
		
		
		 // EX3
		 //Object o=new String("welcome");
		 //StringBuffer sb=(StringBuffer) o;//Rule1-yes rule2-yes rule 3-fail
		 
		 
		 //EX4
		//Object o=new String("welcome");
		//StringBuffer sb=(String) o; //rule 1-yes rule2-fail
		
		
		//EX5
		//String s=new String("welcome");
		//StringBuffer sb=(String) s; //rule 1-yes, rule 2-fail
		
		//EX6
	//Object o=new String("welcome");
	//StringBuffer sb=(StringBuffer) o;//rule 1-yes, rule2-yes, rule 3-fail
	
	
			//EX7	
				
		Object o=new String("welcome");
		String s=(String) o;
		System.out.println(s);

				
				

	}

}
