package day19;

//Cat ct=(Cat) an;// a b c d

class Animal{}        //{}empty class

class Dog extends Animal{}
class Cat extends Animal{} 



public class TypeCastingObject2 {

	public static void main(String[] args) {
		//Rule 1: Conversion id valid or not
		// the type 'd' and 'c' must have relationship (either parent to child or child to parent)
		
		//Animal an=new Dog();
		//Cat ct=(Cat)an;  //valid-an is the parent class variable and ct is the child class variable so relation exits
		
		//Dog dg= new Dog();
		//Cat ct= (Cat) dg //not valid as there is no relation between dg child class variable and Cat class

		//Rule 2: Assignment is valid or not
		//'C' must be same or child of 'A'
		
		//Animal an= new Dog();
		//Cat ct=(Cat) an; //valid as 'C' is same as A
			
		//Animal an= new Dog();
		//Cat ct=(Dog) an;		//invalid as per rule 2
		
		//Rule 3
		//The underlying object type of 'd' must be either same or child of 'c'
		
		//Animal an= new Dog();
		//Cat ct= (Cat) an; //here we get run time error(java.lang.ClassCastException) and not a compile time error
		
		//For rule 1 and rule 2 will give compile time error
		
		//as per rule 3 underlying object of 'an' is Dog. so underlying object should be Cat or child of cat
		//Dog is not Cat and not a child of Cat
		
		
		//Rule 1 rule 2 and rule3
		
		Animal an= new Dog();
		Dog dg= (Dog) an; //all three rules satisfied
		
		
		
	}

}
