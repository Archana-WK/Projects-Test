package day19;

class Parent
{
	String name="Test";
	void m1()
	{
		System.out.println(name);
	}
}

class Child extends Parent
{
	int a=100;
	void m2()
	{
		System.out.println(a);
	}
}

public class TypeCastingObject {

	public static void main(String[] args) {
		
		/*Child ch=new Child();
		System.out.println(ch.name);
		ch.m1();
		System.out.println(ch.a);
		ch.m2();*/
		
		//Upcasting-
		
		Parent p=new Child(); //Child object added to p parent object referance
		System.out.println(p.name);
	    p.m1();
	    p.m2();
		
		

	}

}
