package day10;

public class Employee {
	
	//class without main method
	
	//Class Variables
	int eid;
	int esalary;
	String name;
	String job;
	
	//methods
	void display()  //methods should have return type
	{
		System.out.println(eid);
		System.out.println(esalary);
		System.out.println(name);
		System.out.println(job);
		
	}
}
	

	/*public static void main(String[] args) {
		
		//Object //object are always created under main method
		
		Employee emp1=new Employee(); //emp1 is object created using new keyword
		emp1.eid=101;
		emp1.esalary=1000;
		emp1.name="John";
		emp1.job="wireman";
		emp1.display();
		
		
		Employee emp2=new Employee();
		emp2.eid=102;
		emp2.esalary=2000;
		emp2.name="NEEL";
		emp2.job="Shooter";
		emp2.display();
				
		

	}

}*/
