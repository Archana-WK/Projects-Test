package day10;

public class Student {
	
	//class variable
	int sid;
	String sname;
	
	//method
	void printdata()//void as returns nothing simply it prints
	{
		System.out.println(sid+" "+sname);
	}
	

}
