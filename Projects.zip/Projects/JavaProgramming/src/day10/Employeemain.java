package day10;

public class Employeemain {

	public static void main(String[] args) {
		//class with main method. Employee class called creating object under main method
		Employee emp1=new Employee(); //emp1 is object created using new keyword
		emp1.eid=101;
		emp1.esalary=1000;
		emp1.name="John";
		emp1.job="wireman";
		emp1.display();
		
		
		Employee emp2=new Employee();
		emp2.eid=102;
		emp2.esalary=2000;
		emp2.name="NEEL";
		emp2.job="Shooter";
		emp2.display();
				
		

	}

}
