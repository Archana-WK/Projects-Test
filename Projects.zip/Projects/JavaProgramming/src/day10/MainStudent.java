package day10;

public class MainStudent {

	public static void main(String[] args) {
		
		//calling a class by creating an object (stu1)
		Student stu1=new Student();
		stu1.sid=100;
		stu1.sname="jay";
		stu1.printdata(); //calling methods
		

	}

}
