package day11;

public class StudentMain {

	public static void main(String[] args) {
		
		/*//object reference variable
		Student stu=new Student();
		
		
		stu.stid=01;
		stu.sgrad='a';
		stu.sname="anil";
		stu.printdata();
		
		//Using method
		stu.setdata(02,"sunil", 'b');
		stu.printdata();*/
		
		//Using constructor
		Student stu1=new Student(03,"nitin", 'c');
		stu1.printdata();
		

	}

}
