package day11;

public class Student {
	//class variable
	int stid;
	String sname;
	char sgrad;
	
	void printdata()
	{
		System.out.println(sname+"  "+stid+"  "+sgrad);
	}
	
	//method
	void setdata(int id,String name,char gr)
	{
		stid=id;
		sname=name;
		sgrad=gr;
		
	}
	
	//Constructor
	
	Student(int id,String name,char gr)
	{
		stid=id;
		sname=name;
		sgrad=gr;
		
	}
}


