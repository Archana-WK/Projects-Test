package day11;

public class Greetings {

	void grt()
	{
		System.out.println("hello");
	}

//2 No param Return value

String grt2()
{
	return("Hello how r u?");
}

//3 Take param no return

void grt3(String name)  //no return so type void
{
	System.out.println("Hello "+name);
}

//4 take param return value

String grt4(String surname) 
{
	return("Hello "+surname); //mandatory for returning
}


}