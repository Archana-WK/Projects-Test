package day11;

public class ConstructorDemo {
	int m,n;

	ConstructorDemo()
	{
		
		n=200;
		m=100;
		
	}
	
	ConstructorDemo(int a, int b)
	{
		m=a;
		n=b;
	}
	
	void print()
	{
		System.out.println(m+n);
	}
	
	public static void main(String[] args) {
		ConstructorDemo cd=new ConstructorDemo(2,3); //invoke parameterized constructor
		ConstructorDemo cd1=new ConstructorDemo(); //invoke default constructor
		cd.print();
		cd1.print();

	}

}
