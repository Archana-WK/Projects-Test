package day11;

public class GreetingsMain {

	public static void main(String[] args) {
		//Creating an object call method
		
		Greetings g=new Greetings();
		
		//g object invoke all methods under class Greetings
		
		g.grt(); // 1 No param no return value
		
		String s=g.grt2();//2 No param returns
		System.out.println(s);
		
		g.grt3("neha"); //3 Input param no return
		
	String s1=g.grt4("Ahuja");
    System.out.println(s1);
	}

}
