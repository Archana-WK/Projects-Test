package day1;

public class FirstJavaProgram {

	public static void main(String[] args) {
		
		System.out.println ("Hello");
		
	}

}
