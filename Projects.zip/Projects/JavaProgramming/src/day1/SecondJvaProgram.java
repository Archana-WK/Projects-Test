package day1;

public class SecondJvaProgram {

	public static void main(String[] args) {
		int a=10;
		System.out.println(a);
		char ch='q';
		System.out.println(ch);
		String b="true";
		System.out.println(b);
		
		long l=12345674567890l;//literal l is required 
		System.out.println(l);
		
		final int d=100;
		System.out.println(d);
		int c=10;
		int e=20;
		System.out.println(c>e);
		
		
	}

}
