package day18;

import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		//Example 1
		System.out.println("Progrm started");
		Scanner sc=new Scanner(System.in);
		/*System.out.println("Entre number:");
		int num = sc.nextInt();
		System.out.println(100/num);  //ArithmeticException*/
		
		
		//Example 2
		
		int a[]=new int[5];
		/*System.out.println("Entre position:(0-4)");
		int pos=sc.nextInt(); //ArrayIndexOutOfBoundsException// this is a class and its parent class in Exception
		System.out.println("Entre value:(0-4)");
		int value=sc.nextInt();
		a[pos]=value;
		System.out.println(a[pos]);*/
		
		//Example 3
		/*String s="Welcome";
		int s1=Integer.parseInt(s);//NumberFormatException//this is a class and its parent class in Exception
		System.out.println(s1);
		System.out.println("Progrm completed");
		System.out.println("Progrm exited");*/
		
		//Example 4
		String s2=null; //NullPointerException//this is a class and its parent class in Exception
		System.out.println(s2.length());
		
		
		
	}

}
