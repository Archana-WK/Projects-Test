package day18;



public class CheckedException {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("The program started");
		System.out.println("The program is in progress...");
		
		Thread.sleep(5000);
		
	/*	try
		{
			Thread.sleep(5000); //this will create the checked exception
		}
		catch(InterruptedException e)
		{
			
		}*/
		  
		
		System.out.println("The program completed");
		System.out.println("The program is finished...");
	}

}
