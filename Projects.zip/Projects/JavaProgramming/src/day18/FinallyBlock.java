package day18;

public class FinallyBlock {

	public static void main(String[] args) {
		System.out.println("Progrm started");
		
		String s2=""; //NullPointerException//this is a class and its parent class in Exception
		
		
		try
		{
			System.out.println(s2.length());
		}
		catch(ArithmeticException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
		}
		finally 
		{
			System.out.println("Finally block entered");
		}
		
		System.out.println("Program completed");

}
}
