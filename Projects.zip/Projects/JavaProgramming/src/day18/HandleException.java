package day18;

public class HandleException {

	public static void main(String[] args) {
		System.out.println("Progrm started");
		String s2=null; //NullPointerException//this is a class and its parent class in Exception
		
		
		try
		{
			System.out.println(s2.length());
		}
		catch(NullPointerException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
			
		}

	}

}
