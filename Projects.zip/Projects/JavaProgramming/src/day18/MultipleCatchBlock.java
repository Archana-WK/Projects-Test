package day18;

public class MultipleCatchBlock {

	public static void main(String[] args) {
		System.out.println("Progrm started");
		String s2=null; //NullPointerException//this is a class and its parent class in Exception
		
		
		try
		{
			System.out.println(s2.length());
		}
		/*catch(NullPointerException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
			
		}
		catch(ArithmeticException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
			
		}
		catch(NullPointerException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
			
		}
		catch(NullPointerException e) //e is the object ref variable
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
			
		}*/
		catch(Exception e)  //Exception is a parent class of all exception class. 
							//so use it when the exception type not known
		{
			System.out.println(e.getMessage());
			System.out.println("Invalid data....");
		}
	}

}
