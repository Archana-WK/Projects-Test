package day2;

public class WhileLoop {

	public static void main(String[] args) {
		int i=0;
		
		while(true)
		{
			System.out.println("Hello");
			i++;
		
			if(i==5)
			{
					break;
			}
	}

}
}
