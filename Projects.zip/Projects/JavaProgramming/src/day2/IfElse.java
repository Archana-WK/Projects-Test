package day2;

public class IfElse {

	public static void main(String[] args) {
		/*int a=100; int b=200;
		if(a>b) {
			System.out.println("Greater number is" +a);
		}
		else {
			System.out.println("Smaller number is " +a);
		}
	
	}
}*/
		


