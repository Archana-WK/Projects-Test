package day2;

public class ControllingStatement {

	public static void main(String[] args) {
		/*int person_age=25;
		if(person_age>=18)
		{
			System.out.println("eligible for vote");
		}
		else {
			System.out.println("Not eligible for vote");
			
		}
	}
	
}*/

	/*int b=0;
	if(b<=2)
	{
		System.out.println(b);
		b++;
	}
	else 
	{
		System.out.println("Number is greater than 2");
	}
	}
}*/
		
	/*for (int num=0;num<=10;num++) {
		System.out.println(num);
	}
	}
		
	}*/
		/*//post-increment
		int res=10;
		int a=res++;
		System.out.println(a);
	}
}*/
		//Pre-increment
/*
		int res=10;
		int a=++res;
		System.out.println(a);
	}
}*/
		//post decrement
		int b=10;
		int res=b--;
		System.out.println(res);
	}
}
		//predecrement
		/*int b=10;
		int res=--b;
		System.out.println(res);
	}
	}*/
	
			
			
		
		
		
		
	
