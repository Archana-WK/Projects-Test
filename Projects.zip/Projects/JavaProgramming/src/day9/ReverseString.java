package day9;

public class ReverseString {

	public static void main(String[] args) {
		
		//approach 1=using length()  charAt()
		
		String s="welcome";
		String rev="";
		for(int i=s.length()-1;i>=0;i--)
		{
			rev=rev+s.charAt(i);
		}
		System.out.println("reverse string is " +rev);
		
		
		//approach2= converting String array to char array
		String s1="selenium";
		char ch[]=s1.toCharArray();  //this method will convert a string in char array
		String rev1="";
		for(int j=ch.length-1;j>=0;j--)
		{
			rev1=rev1+ch[j];
		}
		System.out.println("Reverse string is "+rev1 );
		
		
		//approach 3-using StringBuffer class
		
		StringBuffer s2=new StringBuffer("Party");
		System.out.println("reverse string is "+s2.reverse());
		
		
		//approach 3-using StringBuilder class

		StringBuilder s3=new StringBuilder("salesforce");
		System.out.println("reverse string is "+s3.reverse());
	}

}
