package day9;

public class Stringcamparison {

	public static void main(String[] args) {
		//case1
		String s1="welcome"; //string variable s1 and s2 are created
		String s2="welcome";
		System.out.println(s1==s2);  //== campares the object
		System.out.println(s1.equals(s2));  //equals method campare the value of an object
		
		//case2
		
		String s3=new String("welcome");  //new keyword creats the object
		String s4=new String("welcome");  //s3 and s4 are new saparate objects holding same value
		System.out.println(s3==s4);  //== campares the object-s3 and s4 are different objects so false
		System.out.println(s3.equals(s4));  //equals campares the value of object so true
		
		//case3
		System.out.println("***************************");
		String s5="welcome";
		String s6=new String("welcome");
		System.out.println(s5==s6);  //== campares the object-s5 is a variable  and s4 is objects so false
		System.out.println(s5.equals(s6));
		
		//case4
		System.out.println("***************************");
		String s7="welcome";
		String s8=new String("welcome");
		String s9=s8;
		System.out.println(s7==s8); 
		System.out.println(s8==s9); //object assigned to variable-campares the object so true
		System.out.println(s8.equals(s9));
		
	}

}
