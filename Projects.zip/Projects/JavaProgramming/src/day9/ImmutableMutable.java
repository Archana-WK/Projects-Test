package day9;

public class ImmutableMutable {

	public static void main(String[] args) {
		// String is immutable
		
		String s=new String("Welcome");
		s.concat("to java");
		System.out.println(s);  //original value of s is not changed now so Immutable
		
		//StringBuffer-mutable
		StringBuffer s1=new StringBuffer("Welcome");
		s1.append("to java");
		System.out.println(s1);  //original value of s1 is changed now so mutable
		
		//StringBuilder
		StringBuilder s2=new StringBuilder("Welcome");
		s2.append("to class");
		System.out.println(s2);//original value of s2 is changed now so mutable
		
		

	}

}
