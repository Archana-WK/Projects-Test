package day13;

public class thiskeyword {
	
	int x;   //class variable
	int y;
	
	//constructor
	
	/*thiskeyword(int x, int y)
	
	{
		/*x=x; //it will take default value of print i.e.0
		y=y;*/
		
		//this.x=x;
		//this.y=y;
		
    //}
	//methods

	/*void printdata(int a, int b)
	{
		x=a;
		y=b;
		
	}*/
	void printdatathis(int x, int y)
	{
		this.x=x;
		this.y=y;
		
	}
	
	void display()
	{
		System.out.println(x);
		System.out.println(y);
	}
	

	public static void main(String[] args) {
		
		//thiskeyword th=new thiskeyword(2,3); //here the we invoke the constructor directly
		
		thiskeyword th=new thiskeyword();
		th.printdatathis(5,6);
		th.display();
			
		
	}

}
