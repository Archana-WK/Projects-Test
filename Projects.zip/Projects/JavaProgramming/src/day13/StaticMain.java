package day13;

public class StaticMain {

	public static void main(String[] args) {
		
		//static method invoke static stuff directly when it is under same class
		// when main method is under other class specify the class name to access static stuff
		
		//System.out.println(a); //error as it is under other method
		//m1(); //so access thr class name
		
		System.out.println(Staticdemo.a);
		Staticdemo.m1();
		
		
		//static method invoke non static stuff thr object	
		
		Staticdemo st=new Staticdemo();
		System.out.println(st.b);
		st.m2();
		st.m();
	}

}

