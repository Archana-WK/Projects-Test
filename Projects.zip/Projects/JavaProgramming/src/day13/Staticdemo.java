package day13;

public class Staticdemo {
	
	static int a=10;
	int b=20;
	
	static void m1()
	{
		System.out.println(a);
		//System.out.println(b); //gives error as it can be accessed thr object
		
	}
	
	void m2()
	{
		System.out.println(b);
	}
	
	//non static method can access everything directly
	void m()
	{
		System.out.println(a);
		System.out.println(b);
		m1();
		m2();
		
	}
	
	
//public static void main (String [] args){
	
	/*//static method invoke static stuff directly
	System.out.println(a);
	m1();
	
	
	//static method invoke non static stuff thr object	
	
	Staticdemo st=new Staticdemo();
	System.out.println(st.b);
	st.m2();
	st.m();*/
	

}
