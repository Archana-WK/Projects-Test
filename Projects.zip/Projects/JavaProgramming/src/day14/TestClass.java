package day14;

//multiple inheritance is not possible as test1 and test2 classes belongs to methods of object class by default

class test1
{
	void t1 (int t1)
	{
		System.out.println(t1);
	}
}

class test2
{
	void t2 (int t2)
	{
		System.out.println(t2);
	}
}

public class TestClass {

	public static void main(String[] args) {
		test1 t11=new test1();
		t11.   // here the methods invoked are from the Object class
		
		test2 t22=new test2();
		t22.  // here the methods invoked are from the Object class
		
// so t11 and t22 are having duplicate methods so if class c is inherited after extend keyword then class c will
		//not understand the from which class to invoke common method
	}

}
