package day14;

class A
{

	int a;
	void m1()
	{
		System.out.println(a);
	}
	
}

class B extends A
{
	int b;
	void m2()
	{
		System.out.println(b);
	}
	
	
}

class C extends B
{
	int c;
	void m3()
	{
		System.out.println(c);
	}
}




public class Inheritnacetypes {

	public static void main(String[] args) {
		
		//now here the class B is the child of class A. Class A is parent.
		//class B extends all the variable and methods of class a
		//hence need to create the object of child class B
		
/*B bobj=new B();
System.out.println(bobj.a);
System.out.println(bobj.b);
bobj.m1();
bobj.m2();

	}*/
		
	//class c extends to B so c is the grand child of A and B is parent for C
		
		C cobj=new C();
		
		cobj.a=100;
		cobj.b=200;
		cobj.c=300;
		
		cobj.m1();
		cobj.m2();
		cobj.m3();
		

}
}
