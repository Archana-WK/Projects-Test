package day14;

public class Passparamtomainmethod {

	public static void main(String[] args) {
		//string is the array and the args is the name of that string array
		//instead of args we can use any string
		//parameters to string are passed from run as configuration
		
		System.out.println("Testing....");
		System.out.println("Arguments are"+" "+args.length);
		System.out.println(args[0]);
		
		//to fetch the values of the string arguments
		 for(String x: args)
		 {
			 System.out.println(x);
		 }
	}

}
