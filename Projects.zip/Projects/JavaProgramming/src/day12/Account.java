package day12;

//getter setter methods

public class Account {
	//private variables
	
	private int accno;
	private String accname;
	private double amount;
	
	//for each private variable one get and one set method need to be create
	//this keyword is used to identify the class variables when the variable name is same as local variable
	
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccname() {
		return accname;
	}
	public void setAccname(String accname) {
		this.accname = accname;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	
	
	

}
