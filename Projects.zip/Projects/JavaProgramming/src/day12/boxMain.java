package day12;

public class boxMain {

	public static void main(String[] args) {
		//Box bx=new Box();
		//Box bx=new Box(1.1);
		Box bx=new Box(1.1,1.2,1.3);
		

	}

}
