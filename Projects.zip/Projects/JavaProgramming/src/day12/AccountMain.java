package day12;

public class AccountMain {

	public static void main(String[] args) {
		
		Account acc=new Account();
		
		//variable are operated through method only
	   // variables can not be accessed directly
		
		acc.setAccno(101);
		acc.setAccname("John");
		acc.setAmount(1000.10);
		
		acc.getAccno();
		acc.getAccname();
		acc.getAmount();
		
System.out.println(acc.getAmount());
	
}
}
