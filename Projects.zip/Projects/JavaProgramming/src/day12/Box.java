package day12;

public class Box{
	double width, height, length;
	//constructor created with class name
	Box()
	{
		width=1.1;
		height=2.2;
		length=3.3;

		System.out.println(width*height*length);
	}
	
	Box(double length)
	{
		width = height = length;
		System.out.println(width*height*length);
	}
	
	Box(double wd,double ht,double ln)
	{
		width=wd;
		height=ht;
		length=ln;
		System.out.println("volume"+" "+wd*ht*ln);
	}
}
