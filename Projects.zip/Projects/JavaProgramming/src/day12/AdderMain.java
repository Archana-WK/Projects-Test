package day12;

public class AdderMain {

	public static void main(String[] args) {
		Adder ad= new Adder();
		
		ad.sum();
		ad.sum(1, 2.1);
		ad.sum(3,3);
		ad.sum(1, 1, 9);

	}

}
