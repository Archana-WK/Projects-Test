package day12;

public class overloadingMainmethod {
	
	void main(int x)
	{
		System.out.println(x);
	}
	
	void main(String a, String b)
	{
		System.out.println(a+b);
	}

	public static void main(String[] args)
	
	//args-its a string array type just a parameter name--
	//thr command line argument we can pass the String[] args parameter-then only jvm will be able to identify the main method
	{
		
		//create the object to invoke method
		
		overloadingMainmethod ov=new overloadingMainmethod();
		ov.main(2);
		ov.main("test", "main");
		

	}

}
