package day12;

public class Adder {
	int a=1;
	int b=2;
	
	void sum()
	{
		System.out.println(a+b);
		
	}
	
	/*int sum()    //duplicate of sum()
	{
		return(a+b);
	}*/
	
	void sum (int a, int b)
	{
		System.out.println(a+b);
	}
	
	void sum(int a, double b)
	{
		System.out.println(a+b);
	}
	
	void sum(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}

}
