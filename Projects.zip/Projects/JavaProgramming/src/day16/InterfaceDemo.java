package day16;

interface Shape  //Interface syntax is same as class//Interface have three types of methods
{
	int Length=10;
	int Width=20;
	
	void circle();  //Abstract method not having body
	
	default void square()    //default method
	{
		System.out.println("This is square method");
	}
	
	static void rectangle()   //static method
	{
		System.out.println("This is rectangle method");
	}
	
}



public class InterfaceDemo implements Shape 
{
	//Implement the Shape interface
	
	public void circle()  //public keyword needed as interface methods are public 
	{
		System.out.println("This is circle method");
		
	}	
	
	void trianle()
	{
		System.out.println("This is triangle");
	}
	 int x=100;
	 int y=200;

	public static void main(String[] args)
	{
		//Scenario 1
		
		InterfaceDemo idobj= new InterfaceDemo(); //here the object of class is created and stored in class variable
		 idobj.circle();
		 idobj.square();
		 idobj.trianle();
		System.out.println(idobj.x+idobj.y);
		
		 
		 Shape.rectangle();  //rectangle is static method which can be accessed directly thr class or interface
		 //without creating object. here static method is under Interface so call by interface name
		 //no object creation is required to access the static method
		 
		 Shape.rectangle();
		 
		 //Scenario 2
		 
		 Shape sh=new InterfaceDemo(); //here the object of class is created and stored in interface variable
		 //this is possible as Shape interface is implemented in InterfaceDemo class
		 
		 sh.circle();
		 sh.square();
		 
		 Shape.rectangle(); //static method accessed through Interface
		// sh.triangle();//not possible-this method belongs to class and not to interface
		 
		 System.out.println(Shape.Length*Shape.Width);
		 
		// System.out.println(sh.x+sh.y); //variable can not access
		 
		
	}

}
