package day16;

public interface I2 {
	int y=200;
	void m2(); //abstract method

}
