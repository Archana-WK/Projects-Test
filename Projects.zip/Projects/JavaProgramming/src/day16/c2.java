package day16;

public class c2 {
	int z=300;
	static int k=400;
	void m3()
	{
		System.out.println(z);
	}
	static void m4()
	{
		
		System.out.println(k);
	}

}
