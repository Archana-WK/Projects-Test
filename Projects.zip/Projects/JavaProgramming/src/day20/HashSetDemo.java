package day20;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetDemo {

	public static void main(String[] args) {
		// Declaration-either of below one we can use
		
		HashSet myset=new HashSet();			//creating an object of HashSet//store the heterogeneous value
		//Set myset=new HashSet();				//storing child class object HashSet in parent class Set//store the heterogeneous value
		//HashSet <String>myset=new HashSet<String>();//to store the homogeneous value
		
       // Adding elements in HashSet
		
		myset.add(100);
		myset.add('A');
		myset.add("WELCOME");
		myset.add(10.5);
		myset.add(100);
		myset.add(null);
		myset.add(true);
		myset.add(null);
		
		//Printing all the values 
		
		System.out.println("The set is" +myset);//[null, A, 100, 10.5, WELCOME, true]
		
		//removing element
		myset.remove('A');
		System.out.println("After removing" +myset); //null, 100, 10.5, WELCOME, true
		
		//Inserting element-Not Possible
		//Access specific element-Not possible directly but below way its possible
		
		// size of HashSet
		System.out.println(myset.size());
		
		//Printing HashSet values
		//1. Using advanced for loop
		
		for(Object x:myset)
		{
			System.out.println(x);
		}
		System.out.println("*************************");
		
		//2. Using Iterator
		
		Iterator it=myset.iterator();  //(Iterator is a method in arraylist) calling iterator method
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		 System.out.println("*************************");
		
		//Convert HashSet to ArrayList
		ArrayList al=new ArrayList(myset);
		System.out.println(al);           //[null, 100, 10.5, WELCOME, true]
		System.out.println(al.get(3));    //WELCOME
		
		//to remove all elements use clear()
		//isempty()
		
	}

}
