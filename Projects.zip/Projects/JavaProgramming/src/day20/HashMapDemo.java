package day20;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class HashMapDemo {

	public static void main(String[] args) {
		

		//Declaration
		
		HashMap<Integer,String> hm=new HashMap<Integer, String>();
		//Map hm=new HashMap(); store the child class in Parent interface
		
		hm.put(101, "John");
		hm.put(101, "Gail");
		hm.put(101, "sally");
		hm.put(101, "madhu");
		
		System.out.println(hm);		//duplicates are not allowed
		
		hm.put(101, "John");
		hm.put(102, "Gail");
		hm.put(103, "sally");
		hm.put(104, "madhu");
		
		System.out.println(hm);
		
		//size of HashMap
		System.out.println(hm.size());
		
		//Remove
		hm.remove(101);
		System.out.println("After removing the key"+hm);
		
		//access the value
		System.out.println(hm.get(102));
		
		//get all the keys from HashMap
		
		System.out.println(hm.keySet());
		System.out.println(hm.values());
		System.out.println(hm.entrySet());
		
		//replace
		hm.put(101, "scott");
		System.out.println(hm);
		
		//Reading data from hashmap
		//1. Enhanced for loop- for this we need the keys so we start from reading key and then retrive the value
		
		/*for(int k:hm.keySet())       // k will hold the key of hm object
		{
			String val= hm.get(k);   //get method will retrive the values of key stored in k
			System.out.println(k+"    "+val);
		}*/
		
		
		//2. Using Iterator
		//we can not call iterator method directly from hm so extract only keys from hm using keyset
		
		Iterator<Entry<Integer, String>>it=hm.entrySet().iterator();
		
		//hm.entrySet() has key values set like pair
		//now it has those pair 
		//it.next will return first pair of key and values
		
		
		while(it.hasNext())
		{
			//System.out.println(it.next());
			
			Entry<Integer, String> entry=it.next();
			//Entry<Integer, String> this is return type of next() method
			
			System.out.println(entry.getKey()+"   "+entry.getValue());
			
		}
	}

}
