package day20;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		//Declaration- two type of declaration/either of one we can use
		
		ArrayList mylist=new ArrayList(); //for arraylist created a object and obj ref variable mylist
		
		//List mylist= new ArrayList() //List is the parent class and child class object is stored is parent class
		
		//to store the homogenious data below syntax is used
		
		//ArrayList mylist=new ArrayList();//stores all hetrogeneous data
		
		//ArrayList <Integer>mylist=new ArrayList<Integer>();//wrapper class needed to store homogeneous data
		
		//adding data into arraylist
		mylist.add(100);
		mylist.add(10.50);
		mylist.add("welcome");
		mylist.add('A');
		mylist.add(true);
		mylist.add(null);
		mylist.add(null);
		
		//size of an arraylist
		System.out.println(mylist.size());
		
		//Printing arraylist
		System.out.println("Elements in the arraylist are"+mylist);
		
		//Removing the elements from arraylist-//removing a particular element
		mylist.remove(5);
		System.out.println("After removing Elements in the arraylist are"+mylist);
		
		//Insert element in the array list  //adding and insertion is different
		//add method will add the values in the end of the list--here we pass only value and not the index
		//Insertion is adding value with index
		
		mylist.add(0,200);
		System.out.println("After insertion"+mylist);
		
		//modity/replace the value in the arraylist
		
		mylist.set(0,300);
		System.out.println("After replacing"+mylist);
		
		//Access specific element
		System.out.println(mylist.get(3));//3 is the index
		
		//Reading all the elements from the arraylist
		
		//1. using normal for loop
		for(int i=0;i<mylist.size();i++)
		{
			System.out.println(mylist.get(i));
			
		}
		
		//2. using enhanced for loop
		for(Object x:mylist) //x is holding heterogeneous data (not one kind) so we use Object modifier
		{
			
			System.out.println(x);
		}
		
		//3. using Iterator --> this is used for all kind of collections only--> Iterator is method in arraylist
		//it will not follow indexing
		
		//mylist.iterator();- this will call the iterator method from mylist
		//iterator method will return the iterator type object so we need to create the variable to store iterator object
		//iterator will always go with while loop as we do not know how much or is the data available in the arraylist
		//so each time if the data is present that will be exported then go for next data if it available
		
	Iterator it=mylist.iterator(); //this will not create an object but create an object ref variable
	
	    //System.out.println(it.next()); //this will return only first value
		
		while (it.hasNext()) //this will check if the value is present or not if yes then it will in loop
		{
			System.out.println(it.next()); //this will print the value. Again it will go for hasnext and check next value
		}
		
		//removing all elements- clear()method is used.
		
		//removing a set of elements-
		//create another array with elements to be removed-and add that array to removeAll method from the original object
		
		ArrayList mylist2=new ArrayList();
		mylist2.add(100);
		mylist2.add('A');
		System.out.println(mylist2);
		
		mylist.removeAll(mylist2);
		System.out.println("After removing set of data"+mylist);
		
		//checking if the array is empty or not
		
		System.out.println(mylist.isEmpty());
		
		
		
		
	}
	

}
