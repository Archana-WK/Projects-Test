package day8;

import java.util.Arrays;

public class Stringmethods {

	public static void main(String[] args) {
		//concat method
		String s1="Hello";
		String s2="Welcome";
		String s3="Test";
		String s5="welcome";
		String s6="Welcome";
		System.out.println(s1.concat(s2).concat(s3));
		//other method of declaration
		String s=new String("India");
		System.out.println(s);
		System.out.println("hello".concat(s2));
		
		//trim-remove spaces left and right side
		String s4="   welcome   ";
		System.out.println("before trimming "+s4.length());
		System.out.println(s4.trim());
		System.out.println("after trimming "+s4.trim().length());
		
		//charAt()-returns char from string based on index 
		System.out.println(s4.charAt(3));
		System.out.println(s4.trim().charAt(3));
		
		//contains()--returns true or false when the string passed is a part of main string
		
		System.out.println(s2.contains(s3));
		System.out.println(s2.contains(s4));
		System.out.println(s2.contains("wel"));
		System.out.println(s2.contains("Wel"));
		
		//equals(), equalIngnoreCase()--compare string
		System.out.println(s4.equals(s5));
		System.out.println(s4.trim().equals(s5));
		System.out.println(s5.equalsIgnoreCase(s6));
		
		
		//replace()-replace single or multiple characters in a string
		s="join the java selenium";
		System.out.println(s.replace('j','p'));
		System.out.println(s.replace("join","call"));
		
		//substring-extract substring from mail string
		//welcome=0123456-starting index  1234567-ending index
		System.out.println(s.substring(0, 3));
		
		//split-split the string into multiple parts based on delimeter (, @ are called as delimeter)
		//* % / ^ &() can not be used as delimeter
		//split method returns arr
		String s7="abc@gmail.com";
		String a[]=s7.split("@");
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(Arrays.toString(a));
		
		String amount="$15,20,30";   //152030
		System.out.println(amount.replace("$",""));
		
		String d="abc@xyz";
		String ar[]=d.split("@");
		System.out.println(ar[0]);
		System.out.println(Arrays.toString(ar));
		
		String s8="abc@123,com";
		String ar1[]=s8.split("@");//abc 123.com
		System.out.println(Arrays.toString(ar1));
		System.out.println((ar1[0]));
		
		String ar2[]=ar1[1].split(","); //123 com
		System.out.println(Arrays.toString(ar2));
		System.out.println(ar2[0]);
		System.out.println(ar2[1]);
		System.out.println(ar1[0]+ar2[0]+ar2[1]);//abc123com
		
		
		
		
	}
	
		
		
		
		

	}


