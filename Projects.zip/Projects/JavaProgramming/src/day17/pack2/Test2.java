package day17.pack2;
import day17.pack1.Test1;

public class Test2 extends Test1 {
	//Test1 is parent of Child Test2

	public static void main(String[] args) {
		// access to default variable from other pack
		 
		//Test1 t1=new Test1();
		//System.out.println(t1.x); //not possible
		
		Test2 t2=new Test2();
		System.out.println(t2.x2);
		
		/*
		Test1 t1=new Test1();
		System.out.println(t1.x2);*/
		
		
	}

}
