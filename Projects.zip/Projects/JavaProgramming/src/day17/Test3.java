package day17;
import day17.pack1.Test1;

public class Test3 {

	public static void main(String[] args) {
		
		/*Test1 t=new Test1();
		System.out.printl(t.x);*/
		
		Test1 t3=new Test1();
		System.out.println(t3.x2);
		
			

	}

}
