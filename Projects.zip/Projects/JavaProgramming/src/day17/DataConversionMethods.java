package day17;

public class DataConversionMethods {
		
	public static void main(String[] args) {
		//String sobj =new String("Test") or String s="Test" --> so string is predefined class we can create obj of its and can
		//call methods of it
		//String to integer
		
		String s1="10";
		String s2="20";
		System.out.println(Integer.parseInt(s1)+Integer.parseInt(s2));
		
		//String to double
		String d1="10.3";
		String d2="10.3";
		System.out.println(Double.parseDouble(d1)+Double.parseDouble(d2));
		
		//String to boolean
		
		String b1="True"; //other than true if you pass any string it will return false
		System.out.println(Boolean.parseBoolean(b1));
		
		//Primitive data types to String
		int a=10;
		double d=10.5;
		char c='A';
		boolean b = true;
		
		String s=String.valueOf(a);
		System.out.println(s);
		
		String s6=String.valueOf(a);
		System.out.println(s6);
		String s3=String.valueOf(d);
		System.out.println(s3);
		String s4=String.valueOf(c);
		System.out.println(s4);
		String s5=String.valueOf(b);
		System.out.println(s5);
		
	}

}
