package day17.pack1;

public class Test1 {
	
	//default-access only within the package
	
	/*int x2=100;
	void m1()
	{
		System.out.println(x);
	}*/
	 
	/*protected int x2=100;
	protected void m1()
	{
		System.out.println(x2);
	}*/

	
	public int x2=100;
	public void m1()
	{
		System.out.println(x2);
	}
}
