package day17.pack1;


public class pack1class {
	
	//private-access only within class
	
	private static int x1=200;
	

	public static void main(String[] args) {
			
		//can access Test1 class variable/method as in same pack
		
			Test1 t=new Test1();
			System.out.println(t.x);
			
			System.out.println(x1);
			

	}

}
