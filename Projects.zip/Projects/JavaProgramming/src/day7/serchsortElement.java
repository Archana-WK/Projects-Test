package day7;
import java.util.Scanner;

public class serchsortElement {

	public static void main(String[] args) {
	 int a[]= {10,20,30,40,30};
	 int search_element=30;
	 int count=0;
	 boolean test=false;
	 
	 /*for(int i=0;i<a.length;i++)
	 {
		 if(a[i]==search_element)
		 {
			count++;
			test=true;
		
		 }
		 
	 }
	 System.out.println("Element found for "+count+ " times");
	 if(test==false)
	 {
		 System.out.println("Element not found");	 
	 }
	 
	}*/
	 
	 /*Advanced for loop
	 
	 for(int arr:a)
	 {
		 if(arr==search_element)
		 {
			 System.out.println("Element Found");
			 count++;
			 test=true;
		 }
	 }
	 if(test==false)
	 {
		 System.out.println("Element not found");	 
	 }
		 
	 }*/
	 
	 //Scanner class object
	 
	 Scanner sc=new Scanner(System.in);//call scanner class object
	 
	 System.out.println("Entre Number");
	 int num=sc.nextInt();
	 System.out.println("Given number is "+num);
	}
	
	 
	 
	 

}
