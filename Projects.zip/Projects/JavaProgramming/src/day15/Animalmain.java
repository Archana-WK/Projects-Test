package day15;

public class Animalmain {

	public static void main(String[] args) {
		Dog dg=new Dog();
		dg.prinntcolor();
		dg.eat();

	}

}
