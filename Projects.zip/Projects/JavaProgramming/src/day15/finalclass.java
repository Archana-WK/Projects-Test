package day15;
final class first
{
	void test3()
	{
		System.out.println("this is first method");
	}
}

class second extends first   //Final class first can not be extended to sub(child) class
{
	void test3()
	{
		System.out.println("this is second method");
	}
}

public class finalclass {

	public static void main(String[] args) {
		second t3=new second();
		t3.test3();
	

	}

}
