package day15;

class Bank
{
	double roi()
	{
		return 0;
	}
}

class ICICI extends Bank
{
	double roi()    //same method declaration but different implementation i.e. body parts
	{
		return 10.5;
	
	}
}
class SBI extends Bank
{
	double roi()
	{
		return 11.5;
	}
}



public class MethodOverriding {

	public static void main(String[] args) {
		ICICI ic=new ICICI();
		System.out.println(ic.roi());   //here the roi of parent class will not be called as it is overrided 
		
		SBI sb=new SBI();
		System.out.println(sb.roi());  //here the roi of parent class will not be called as it is overrided 
	
		}

}
