package day15;

class ABC
{
	void m1(int a)
	{
		System.out.println(a);
	}
	void m2(int b)
	{
		System.out.println(b);
	}
}

class XYZ extends ABC
{
	void m1(int a)
	{
		System.out.println(a*a); //overriding as only body implementation is changed, declaration is same
	}
	void m2(int b, int c)    //overloading- change is declaration
	{
		System.out.println(b+c);
	}
}

public class Overloadingvsoverriding {

	public static void main(String[] args) {
		
		XYZ ov=new XYZ();
		ov.m1(4);
		ov.m2(9,8);
		ov.m2(10);

	}

}
