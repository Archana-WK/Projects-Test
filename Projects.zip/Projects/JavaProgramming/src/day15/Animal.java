package day15;

public class Animal {
	
	String color="White";
	void eat()
	{
		System.out.println("Nothing...");
	}
	

}

class Dog extends Animal
{
	String color="Black";
	
	void prinntcolor()
	{
		//System.out.println(color); // Black
		System.out.println(super.color); //white
		//as super keyword invokes parent class variable
		//
	}
	void eat()
	{
		System.out.println("Nothing but bread");
		super.eat();
	}
	
	

	
}
