package day15;

class test
{
	final int m=100;
	
	final void change()
	{
		System.out.println("final keyword");
	}
}

class test1 extends test
{
	void change()   //get the error that final method can not be override. change is final method
	{
		System.out.println("final keyword is changed");
	}
	
}


public class finalkeyword {

	public static void main(String[] args) {
	//test tt=new test();
	test1 tt=new test1();
	//tt.m=200;         //after final keyword we can not change the value of m
	System.out.println(tt.m);
	tt.change();
	

	}

}
